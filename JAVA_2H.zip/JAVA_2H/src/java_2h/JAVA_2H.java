/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_2h;

import java.sql.SQLException;

/**
 *
 * @author hadie
 */
public class JAVA_2H {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
       // new configDB().getKoneksi();
    String[] F = { "Judul","Genre","Tahun","Asal","Stok"};
    String[] V = { "Naruto","Anime","2010","Jepang","30"};
    configDB praktikum = new configDB();
    
    //System.out.println(praktikum.getCombineValueFieldArray(F, V));
    praktikum.UbahDinamis("film","KodeFilm","03", F, V);
       
   //versi tabel admin    
    // String[] F = { "username","password","level"};
    //String[] V = { "ramdhani","uniska","admin"};
    //configDB praktikum = new configDB();
    //praktikum.SimpanDinamis("film", F, V);
   // ==========
        //System.out.println(praktikum.getFieldArray(F));
       // System.out.println(praktikum.getValueFieldArray(V));

    
    //praktikum.SimpanFilmStatement("01","AADC","Romance","2018","Indonesia","10");
    //praktikum.SimpanFilmPrepared("02","AADC 2","Romance",2018,"Indonesia",10);
   /* if (praktikum.getDuplikasiKey("film","KodeFilm","12")){
        System.out.println("Data ada");
    }else{
       //System.out.println("Data tidak ada");
       praktikum.SimpanFilmPrepared("12", "Doraemon", "Anime", 2019, "Jepang", 10);
    } */
  // praktikum.HapusDinamis("film", "KodeFilm", "12");
    }  
}
