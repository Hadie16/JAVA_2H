/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package anggota;

import java.sql.SQLException;

/**
 *
 * @author hadie
 */
public class anggota{

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
//IDanggota nama tempat_lahir tgl_lahir	jkl	status	alamat	telp
    String[] F = {"IDanggota","nama", "tempat_lahir","tgl_lahir","jkl","status","alamat","telp" };
    String[] V = {"01","Entoma Vasilissa","Paris","2000-11-11","Perempuan","","Paris","0888888" };
    configDBAnggota praktikum = new configDBAnggota();
    
   // praktikum.UbahDinamis("anggota","IDanggota","01", F, V);
   // praktikum.simpanData("anggota", F, V);

    }  
}
